from sqlalchemy import Column, Integer, String, Float
from sqlalchemy.orm import declarative_base

Base = declarative_base()


class Mahasiswa(Base):
    """Model data mahasiswa dan hasil prediksi kelulusan."""
    __tablename__ = "mahasiswa"

    id = Column(Integer, primary_key=True, index=True)
    nama = Column(String(150), nullable=False)
    ipk = Column(Float, nullable=False)
    sks = Column(Integer, nullable=False)
    status_kelulusan = Column(String(50), nullable=False)
