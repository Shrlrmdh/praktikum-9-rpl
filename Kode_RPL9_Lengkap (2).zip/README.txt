PANDUAN MENJALANKAN APLIKASI RPL 9

1. Buka folder Kode_RPL9 di VS Code.
2. Buka terminal VS Code.
3. Jalankan: pip install -r requirements.txt
4. Jalankan: streamlit run app.py
5. Aplikasi akan terbuka di browser.

ATURAN PREDIKSI:
- IPK minimal 3.0
- Total SKS minimal 140
- Jika kedua syarat terpenuhi: Lulus Tepat Waktu
- Jika tidak: Tidak Lulus

Struktur:
Kode_RPL9/
  app.py
  .env
  requirements.txt
  models/model.py
  repositories/repository.py
  services/service.py
