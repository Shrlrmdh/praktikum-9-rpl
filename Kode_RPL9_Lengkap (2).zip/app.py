import os
import streamlit as st
import pandas as pd
from sqlalchemy import create_engine
from sqlalchemy.orm import sessionmaker
from dotenv import load_dotenv

from models.model import Base
from repositories.repository import MahasiswaRepository
from services.service import PrediksiService

st.set_page_config(page_title="Sistem Prediksi Kelulusan", page_icon="🎓", layout="centered")


@st.cache_resource
def inisialisasi_database():
    load_dotenv()
    database_url = os.getenv("DATABASE_URL", "sqlite:///data_prediksi.db")
    engine = create_engine(database_url, connect_args={"check_same_thread": False})
    Base.metadata.create_all(bind=engine)
    return sessionmaker(bind=engine)


SessionLocal = inisialisasi_database()
service = PrediksiService()

st.title("🎓 Sistem Prediksi Kelulusan")
st.write("Masukkan data mahasiswa untuk memperoleh prediksi berdasarkan IPK dan total SKS.")

with st.form("form_input"):
    nama = st.text_input("Nama Mahasiswa")
    ipk = st.number_input("IPK (0.0 - 4.0)", min_value=0.0, max_value=4.0, value=0.0, step=0.01)
    sks = st.number_input("Total SKS", min_value=0, value=0, step=1)
    tombol_proses = st.form_submit_button("Prediksi & Simpan", use_container_width=True)

if tombol_proses:
    if not nama.strip():
        st.warning("Nama tidak boleh kosong!")
    else:
        status = service.tentukan_kelulusan(float(ipk), int(sks))
        db = SessionLocal()
        try:
            repo = MahasiswaRepository(db)
            repo.simpan_data(nama.strip(), float(ipk), int(sks), status)
            if status == "Lulus Tepat Waktu":
                st.success(f"**{nama.strip()}** dinyatakan **{status}**.")
            else:
                st.error(f"**{nama.strip()}** dinyatakan **{status}**.")
            st.toast("Data berhasil disimpan!")
        finally:
            db.close()

st.divider()
st.subheader("📋 Riwayat Prediksi")

db = SessionLocal()
try:
    repo = MahasiswaRepository(db)
    data_mahasiswa = repo.ambil_semua_data()
    if data_mahasiswa:
        daftar_data = [
            {
                "Nama": item.nama,
                "IPK": item.ipk,
                "SKS": item.sks,
                "Status": item.status_kelulusan,
            }
            for item in data_mahasiswa
        ]
        st.dataframe(pd.DataFrame(daftar_data), use_container_width=True, hide_index=True)
    else:
        st.info("Belum ada data prediksi. Silakan masukkan data mahasiswa terlebih dahulu.")
finally:
    db.close()
